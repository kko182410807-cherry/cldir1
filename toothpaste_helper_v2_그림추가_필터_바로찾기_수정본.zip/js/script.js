
function filterMethods(filter,button){
  document.querySelectorAll('.amount-filter').forEach(b=>b.classList.remove('active'));
  button.classList.add('active');
  document.querySelectorAll('.method-card').forEach(card=>{
    const tags=(card.dataset.amount||'').split(/\s+/);
    card.classList.toggle('is-hidden', filter!=='all' && !tags.includes(filter));
  });
}
function jumpUse(id){
  show('uses');
  setTimeout(()=>{
    const el=document.getElementById(id);
    if(!el)return;
    el.scrollIntoView({behavior:'smooth',block:'center'});
    el.classList.remove('highlight');
    void el.offsetWidth;
    el.classList.add('highlight');
  },120);
}
const P=['home','methods','finder','result','uses','tips'];
function show(id){
  P.forEach(x=>document.getElementById(x).classList.toggle('active',x===id));
  document.querySelectorAll('nav button[data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===id));
  window.scrollTo({top:0,behavior:'smooth'});
  if(id==='finder')render();
}
const M=[['끝에서부터 밀기','치약이 많이 남았거나 중간에 퍼져 있다면 튜브 끝에서 입구 방향으로 천천히 밀어주세요.'],['튜브를 납작하게 정리하기','손바닥으로 튜브를 가볍게 눌러 빈 공간을 줄이고 치약을 한쪽으로 모아주세요.'],['뚜껑을 아래로 세우기','사용 전 잠시 입구가 아래를 향하도록 세워 치약이 자연스럽게 입구 쪽으로 내려오게 해보세요.'],['끝부분 접어 올리기','치약이 절반 이하라면 빈 튜브 부분을 입구 쪽으로 접어 치약이 뒤로 밀리지 않게 해주세요.'],['돌돌 말아 올리기','튜브 끝을 조금씩 말아 올리면서 치약을 입구 쪽에 모아주세요.'],['가볍게 톡톡 세우기','뚜껑을 닫은 상태에서 튜브를 세워 가볍게 톡톡 흔들어 치약을 아래쪽으로 모아주세요.'],['치약 짜개 사용하기','튜브를 짜개에 끼우고 조금씩 돌리면 균일하게 말리면서 남은 치약을 밀어낼 수 있어요.'],['손가락으로 입구 쪽 모으기','튜브 표면을 손가락으로 넓게 훑듯이 입구 방향으로 모아주세요.'],['튜브 자르기는 마지막 선택','정말 적게 남았을 때만 고려하고, 잘린 가장자리와 보관 위생에 주의하세요.']];
const Q=[['치약이 얼마나 남았나요?',['많이 남았어요|튜브 중간 이상|more','절반 정도 남았어요|중간 정도|half','거의 다 썼어요|입구 근처에 조금 남음|little']],['치약이 지금 어디에 모여 있나요?',['입구 쪽에 모여 있어요|입구 가까이에 있음|near','튜브 중간에 퍼져 있어요|안쪽에 넓게 퍼짐|spread','반대쪽 끝에 남아 있어요|끝부분에 남음|end']]];
let qi=0,A=[];
function start(){qi=0;A=[];show('finder')}
function render(){let x=Q[qi];document.getElementById('step').textContent=(qi+1)+' / 2';document.getElementById('progressBar').style.width=((qi+1)/2*100)+'%';document.getElementById('q').textContent=x[0];document.getElementById('qs').textContent='현재 상황과 가장 가까운 것을 선택하세요.';let c=document.getElementById('choices');c.innerHTML='';x[1].forEach(v=>{let a=v.split('|'),b=document.createElement('button');b.className='choice';b.innerHTML=a[0]+'<small>'+a[1]+'</small>';b.onclick=()=>ans(a[2]);c.appendChild(b)});document.getElementById('back').style.visibility=qi?'visible':'hidden'}
function ans(v){A[qi++]=v;if(qi<2)render();else result()}
function prev(){if(qi){qi--;render()}}
function result(){let s=Array(9).fill(0),[a,p]=A;if(a==='more')s[0]+=4;if(a==='half'){s[1]+=3;s[2]+=2;s[3]+=2}if(a==='little'){s[3]+=3;s[4]+=4;s[6]+=3}if(p==='near'){s[0]+=3;s[2]+=2}if(p==='spread'){s[1]+=4;s[0]+=2;s[7]+=2}if(p==='end'){s[3]+=3;s[4]+=4;s[6]+=2}let r=s.map((v,i)=>[v,i]).sort((x,y)=>y[0]-x[0]).slice(0,3);document.getElementById('recs').innerHTML=r.map((x,i)=>`<div class="rec"><b>${i+1}</b><div><h3>${M[x[1]][0]}</h3><p>${M[x[1]][1]}</p></div></div>`).join('');show('result')}
function detail(i){
  const steps=[
    ['튜브 끝을 잡고 입구 방향으로 손바닥으로 천천히 밀어주세요.','한 번에 세게 누르지 말고 이동하면서 치약이 입구에 모이는지 확인하세요.','입구에 모인 뒤 필요한 만큼만 짜세요.'],
    ['튜브를 넓게 눌러 납작하게 만든 뒤 치약이 퍼진 방향을 정리하세요.','공기와 빈 공간을 줄이면서 입구 쪽으로 밀어주세요.','끝부분을 정리해 다음 사용 때도 쉽게 나오게 하세요.'],
    ['뚜껑을 닫고 입구가 아래를 향하게 세워두세요.','잠시 기다린 뒤 입구 주변을 가볍게 눌러주세요.','치약이 입구에 모이면 평소처럼 사용하세요.'],
    ['빈 튜브 부분을 입구 쪽으로 한 번 접어주세요.','접힌 부분을 유지하면서 치약이 뒤로 가지 않게 정리하세요.','필요하면 한 번 더 접어 입구까지 밀어주세요.'],
    ['튜브 끝을 조금씩 말아 올리세요.','말린 부분이 풀리지 않게 잡으면서 입구 방향으로 계속 모아주세요.','거의 다 쓴 튜브에 특히 편합니다.'],
    ['뚜껑을 닫은 상태로 튜브를 세워주세요.','손목에 무리가 가지 않게 가볍게 톡톡 움직여 아래쪽으로 모아주세요.','입구에 모이면 뚜껑을 열고 사용하세요.'],
    ['튜브를 짜개에 맞게 끼우세요.','손잡이를 조금씩 돌려 튜브를 균일하게 말아주세요.','과하게 돌려 튜브를 찌그러뜨리지 마세요.'],
    ['튜브 표면을 손가락 여러 개로 넓게 잡아주세요.','입구 쪽으로 훑듯이 천천히 모아주세요.','특정 한 점만 강하게 누르지 않는 것이 좋아요.'],
    ['가능하면 다른 방법을 먼저 사용하세요.','정말 적게 남았다면 제품과 보관 방법을 확인하세요.','자르는 경우 날카로운 가장자리와 개봉 후 위생에 특히 주의하세요.']
  ][i];
  const card=document.querySelectorAll('.method-card')[i];
  const illustration=card?card.querySelector('.method-illustration').innerHTML:'';
  const extra=i===8?'<div class="safe">⚠ 안전: 튜브를 자르는 방법은 기본 방법으로 권장하지 않습니다. 잘린 부분이 날카로울 수 있고, 개봉 후 보관 위생에도 주의가 필요합니다.</div>':'';
  document.getElementById('detail').innerHTML=`<span class="label">HOW TO</span><h2>${M[i][0]}</h2><p>${M[i][1]}</p><div class="detail-illustration">${illustration}</div><div class="stepbox"><b>STEP 1</b><br>${steps[0]}</div><div class="stepbox"><b>STEP 2</b><br>${steps[1]}</div><div class="stepbox"><b>STEP 3</b><br>${steps[2]}</div>${extra}`;
  document.getElementById('modal').classList.add('open');
}
function closeD(){document.getElementById('modal').classList.remove('open')}
show('home');
